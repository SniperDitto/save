package pkg.Commons;

public interface IFly {
	public void fly();
}
