package pkg.Commons;

public interface IAttack {
	//attack = shotGun 둘다 공격하는 행위로 생각
	public void attack(ITarget unit);
}
