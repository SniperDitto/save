package pkg.Commons;

public interface IProtoss {
	public Races race = Races.Protoss;
}
