package pkg.Commons;

public enum Races {
	Protoss, Zerg, Terran
}
