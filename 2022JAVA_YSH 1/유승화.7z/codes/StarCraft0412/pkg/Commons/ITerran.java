package pkg.Commons;

public interface ITerran {
	public Races race = Races.Terran;
}
