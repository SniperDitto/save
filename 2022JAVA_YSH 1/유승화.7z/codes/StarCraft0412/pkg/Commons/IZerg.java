package pkg.Commons;

public interface IZerg {
	public Races race = Races.Zerg;
}
