package pkg.Commons;

public interface ITarget {
	public void hit(int damage);
}
