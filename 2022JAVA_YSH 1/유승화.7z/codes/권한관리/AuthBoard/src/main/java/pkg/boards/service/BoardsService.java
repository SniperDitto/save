package pkg.boards.service;

import java.util.ArrayList;

import pkg.boards.VO.BoardVO;
import pkg.boards.VO.MemberVO;

public interface BoardsService {
	public ArrayList<BoardVO> getBoardList(String idx);
	public ArrayList<MemberVO> getMemberList(String userID);
	public void saveBoard(String[] idx, String[] title, String[] userID, String[] status);
	public void deleteBoard(String[] idx);
}
